
levels = { # Each level with their respective amount of enemies
    "1": 1,
    "2": 2,
    "3": 3,
    "4": 5,
    "5": 7,
    "6": 2, # 3 Enemies with 120 HP. This is for all enemies pass level 5
    "7": 3,
    "8": 4,
    "9": 5,
    "10": 0, # spawn a boss enemy who deals 50 damage and has 200 HP.
    "11": 6,
    "12": 7,
    "13": 8,
    "14": 9,
    "15": 10
}